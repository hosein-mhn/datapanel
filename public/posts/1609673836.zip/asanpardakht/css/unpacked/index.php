﻿<?php
// Silence is golden :-D
?>
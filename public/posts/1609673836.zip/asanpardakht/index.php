<?php

$pin = "3EE0CC86940D512ABD34"; // gateway pin
//pin khod ra bala vared konid pin bala braye test ast
 

ob_start();
echo '
<!DOCTYPE html>
<html lang="fa">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="Designer" content="Developed by paystar.ir">
		<title>آسان پرداخت</title>
		<link rel="stylesheet" href="css/additionals.css">
		<link rel="stylesheet" href="css/style.css">

		<script src="javascript/jquery-1.11.0.min.js"></script>
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body class="page-payment-redirect page-asanpardakht">
		<div class="wrapper site-wrap" id="site_wrap">
			<div class="container">
				<div class="asanpardakht-box clearfix">
					<div class="asanpardakht-description col-sm-6">
						<i class="icon-pay-per-click ap-icon"></i>
						<img src="images/ap.png" alt="Asan pardakht">
						<p>پرداخت یار پی استار، به لطف روش های متنوع پرداخت و امکانات ویژه خود همواره می کوشد تا پاسخگوی طیف وسیعی از نیازهای تراکنشی و مالی کاربران خود باشد.</p><p>آسان پرداخت پی استار، ابزاری پویا و مطمئن جهت تسهیل تراکنش بین مبداء و مقصد بوده که در آن مشتری با مشاهده مشخصات فروشنده و تعیین مبلغ تراکنش، اقدام به واریز وجه می نماید.</p>
						<p>لطفا قبل از انجام تراکنش از صحت نام فروشگاه و مبلغ پرداختی اطمینان حاصل فرمایید.جهت پیگیری تراکنش خود میتوانید به آدرس <a href="https://paystar.ir/followup">paystar.ir/followup</a> مراجعه کنید.</p>
					</div><!-- .asanpardakht-description -->



					<div class="asanpardakht-form col-sm-6">
						<div class="vendor-information clearfix">
							<div class="vendor-logo col">
								<img src="images/sample/your_logo.png" alt="logo">
							</div><!-- .vendor-logo -->

							<div class="details col">
								<span class="ttl">اطلاعات پذیرنده</span>
								<h2 class="vendor-name">پی استار</h2>
								<a href=""><i class="icon-link"></i> www.example.ir</a>
							</div><!-- .detail -->

							<div class="clearfix"></div>
						</div><!-- .vendor-information -->

						<span class="shadow"></span>

						<div class="pre-payment">
							<span class="icon-logo go-left"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
							<h2 class="ap-title">آسان پرداخت</h2>
							<p>کاربر گرامی جهت انجام عملیات پرداخت ، فرم ذیل را تکمیل نمایید</p>
						</div>
';

$url = $_SERVER['REQUEST_URI']; //returns the current URL
$parts = explode('/',$url);
$callback = $_SERVER['SERVER_NAME'];
for ($i = 0; $i < count($parts) - 1; $i++) {
 $callback .= $parts[$i] . "/";
}
$callback .= "verify.php";

if(! Empty($_POST)){
  $url = 'https://paystar.ir/api/create/'; // don't change
  $description = "";
  if(!Empty($_POST["name"])){
     $description .= "نام و نام خانوادگی : ".$_POST["name"]."\n";
  }
  if(!Empty($_POST["email"])){
     $description .= "ادرس ایمیل : ".$_POST["email"]."\n";
  }
  if(!Empty($_POST["phone"])){
     $description .= "شماره موبایل : ".$_POST["phone"]."\n";
  }
  if(!Empty($_POST["details"])){
     $description .= "توضیحات کاربر : ".$_POST["details"]."\n";
  }
  if(Empty($_POST["amount"]) or $_POST["amount"] < 100){ $_POST["amount"] = '100'; }
 
  $callback .= "?amount=".$_POST["amount"];
  $fields = array(
    'amount' => urlencode($_POST["amount"]),
    'email' => urlencode($_POST["email"]),
    'phone' => urlencode($_POST["phone"]),
    'pin' => urlencode($pin),
    'description' => urlencode($description),
    'callback' => urlencode($callback),
  );
  $fields_string = "";
  foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
  rtrim($fields_string, '&');
  $ch = curl_init();
  curl_setopt($ch,CURLOPT_URL, $url);
  curl_setopt($ch,CURLOPT_POST, count($fields));
  curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $result = curl_exec($ch);
  curl_close($ch);


  if(is_numeric($result)){
    echo '
    <span style="color:red">ارور : '.$result.'</span>';
  } else {
    echo $result;
    header('Location: https://paystar.ir/paying/'.$result);
  }
}

echo '    
									<form class="row" method="post">
										<div class="field-holder col-sm-6">
											<input type="text" placeholder="نام پرداخت کننده" name="name">
										</div>
										<div class="field-holder col-sm-6">
											<input type="text" placeholder="ایمیل پرداخت کننده" name="email">
										</div>
										<div class="field-holder col-sm-6">
											<input type="text" placeholder="موبایل پرداخت کننده" name="phone">
										</div>
										<div class="field-holder col-sm-6">
											<input type="text" placeholder="قیمت" name="amount">
											<span class="suffix">تومان</span>
										</div>
										<div class="field-holder col-sm-12">
											<input type="text" placeholder="توضیحات خرید" name="details">
										</div>
										<div class="clearfix"></div>	
										<button class="dw-submit-button" type="submit">پرداخت آنلاین <i class="icon-credit-card"></i></button>
									</form>
								</div><!-- .asanpardakht-form -->

				</div><!-- .asanpardakht-box -->

			</div><!-- .container -->

			<footer class="payment-footer">
				<p class="copyright">© 2017 PayStar </p>
			</footer>

			<div class="accepted-baks"><img src="images/sample/banks-ver.png" alt="banks"></div>

		</div><!-- #site_wrap -->
		<script src="javascript/plugins.js"></script>
		<script src="javascript/main.js"></script>
	</body>
</html>';
ob_end_flush();
